import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.ArrayList;
import java.util.Arrays;

public class Receiver {
	private static byte[] dataReceived;
	private static ArrayList<byte[]> chunksReceived = new ArrayList<byte[]>();
	private static ArrayList<DatagramPacket> packetsReceived = new ArrayList<DatagramPacket>();
	
	public Receiver() {	
	}
	
	public void receiveData() throws IOException{
        Sender sender = new Sender();
        DatagramSocket ds = new DatagramSocket(4567);
        
        for (int i = 0; i < sender.getNumPackets(); i++) {
            //Create the required number of packets that the sender class will send and then receive them  
            packetsReceived.add(new DatagramPacket(sender.getSpecificPacket(i), sender.getPacketLength(i)));
            }   

   
        for (int i = 0; i < packetsReceived.size(); i++) {
        	try {
        		ds.receive(packetsReceived.get(i));
        	}
        	catch (Exception e) {
        		e.printStackTrace();
        	}
        }
        ds.close();
        System.out.println("Success!");
        }       
      		
	public void createArrays() {
		Sender sender = new Sender();
		for (int i = 0; i < sender.getNumPackets(); i++) {
			chunksReceived.add(packetsReceived.get(i).getData());
		}
	}
	
	public void assembleFile() {
		Sender sender = new Sender();
		dataReceived = new byte[sender.getDataLength()];
		int newLength = 0;
		int index = 0;
		for (int i = 0; i < chunksReceived.size(); i++) {
			newLength = newLength + chunksReceived.get(i).length;
			dataReceived = Arrays.copyOf(dataReceived, newLength);
			for (int j = 0; j < chunksReceived.get(i).length; j++) {
				dataReceived[index] = chunksReceived.get(i)[j];
				index++;
			}		
		}
		System.out.println("The length of dataReceived is: ");
	}
}