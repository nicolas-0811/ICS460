import java.io.*;

public class Application {

	public static void main(String[] args) throws IOException{
		Sender sender = new Sender();
		Receiver receiver = new Receiver();
		sender.readImage();
		sender.imageToBytes();
		sender.sendImagePrint();
		sender.sendImage();	
	
		System.out.println(sender.getPacketLength(0));
	
		receiver.receiveData();
	//	receiver.assembleFile();
		
		System.out.println("Process terminated");
	}
}