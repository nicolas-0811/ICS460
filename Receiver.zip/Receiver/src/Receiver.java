import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.ArrayList;
import java.util.Arrays;

public class Receiver {
	private static byte[] dataReceived;
	private static final int RANDOM_PORT = 111;
	private static ArrayList<byte[]> packetsReceived = new ArrayList<byte[]>();
	
	public Receiver() {	
	}
	
	public static void main(String[] args) throws IOException, InterruptedException {
		Receiver receiver = new Receiver();
		receiver.receiveData();
		receiver.assembleFile();
		receiver.writeFile();
		System.out.println("Success! Check your desktop to see the received image");	
	}	
	
	public void receiveData() throws IOException {
		DatagramSocket ds = new DatagramSocket(RANDOM_PORT);
		byte[] initialSize = new byte[1000]; //Same file size we chose for the sender program
		boolean keepGoing = true;
		
		while(keepGoing) {
			DatagramPacket dp = new DatagramPacket(initialSize, initialSize.length);
			ds.receive(dp);	
			if (dp.getLength() == 0) {
				keepGoing = false;
				break;
			}
			else if (dp.getLength() != initialSize.length) {
				byte[] finalPacket = new byte[dp.getLength()];
				packetsReceived.add(finalPacket);
				System.out.println("Received " + packetsReceived.size() + " packets");
				keepGoing = false;
				break;
			}
			else {
				packetsReceived.add(initialSize);
				System.out.println("Received " + packetsReceived.size() + " packets");	
			}					
		}
			System.out.println(packetsReceived.size() + " packets received in total");
			ds.close();		
		}       
	
	public void assembleFile() {
		dataReceived = new byte[0];
		int newLength = 0;
		int index = 0;
		for (int i = 0; i < packetsReceived.size(); i++) {
			newLength = newLength + packetsReceived.get(i).length;
			dataReceived = Arrays.copyOf(dataReceived, newLength);
			for (int j = 0; j < packetsReceived.get(i).length; j++) {
				dataReceived[index] = packetsReceived.get(i)[j];
				index++;
			}		
		}
		System.out.println("The length of dataReceived is: " + dataReceived.length);
	}
	
	public void writeFile() throws IOException {
		String filePath = System.getProperty("user.home") + "/Desktop" + "/newDog.jpg";
		try (FileOutputStream fos = new FileOutputStream(filePath)) {
		    fos.write(dataReceived);
		} 
		catch (IOException e) {
		    e.printStackTrace();
		}
	}
}