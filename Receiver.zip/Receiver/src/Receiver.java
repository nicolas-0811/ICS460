import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.ArrayList;
import java.util.Arrays;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

public class Receiver {
	private static byte[] dataReceived;
	private static final int RANDOM_PORT = 555;
	private static ArrayList<byte[]> chunksReceived = new ArrayList<byte[]>();
	
	public Receiver() {	
	}
	
	public static void main(String[] args) throws IOException, InterruptedException {
		Receiver receiver = new Receiver();
		receiver.receiveData();
		receiver.assembleFile();
		receiver.writeFile2();
		System.out.println("Success! Check your desktop to see the received image");	
	}	
	
	public void receiveData() throws IOException {
		DatagramSocket ds = new DatagramSocket(RANDOM_PORT);
		byte[] initialSize = new byte[1000]; //Same file size we chose for the sender program
		boolean keepGoing = true;
		
		while(keepGoing == true) {
			DatagramPacket dp = new DatagramPacket(initialSize, initialSize.length);
			ds.receive(dp);	
			if (dp.getLength() == 0) {
				keepGoing = false;
				break;
			}
			if (dp.getLength() != initialSize.length) {
				byte[] finalPacket = new byte[dp.getLength()];
				chunksReceived.add(finalPacket);
				System.out.println("Received " + chunksReceived.size() + " packets");
				keepGoing = false;
				break;
			}
			else {
				chunksReceived.add(dp.getData());
				System.out.println("Received " + chunksReceived.size() + " packets");	
			}					
		}
			System.out.println(chunksReceived.size() + " packets received in total");
			ds.close();		
		}       
	
	public void assembleFile() {
		dataReceived = new byte[0];
		int newLength = 0;
		int index = 0;
		for (int i = 0; i < chunksReceived.size(); i++) {
			newLength = newLength + chunksReceived.get(i).length;
			dataReceived = Arrays.copyOf(dataReceived, newLength);
			for (int j = 0; j < chunksReceived.get(i).length; j++) {
				dataReceived[index] = chunksReceived.get(i)[j];
				index++;
			}		
		}
		System.out.println("The length of dataReceived is: " + dataReceived.length);
	}
	
	public void writeFile() throws IOException {
		String filePath = System.getProperty("user.home") + "/Desktop" + "/NewDog.jpg";
		try (FileOutputStream fos = new FileOutputStream(filePath)) {
		    fos.write(dataReceived);
		} 
		catch (IOException e) {
		    e.printStackTrace();
		}
	}
	
	public void writeFile2() throws IOException {
		String filePath = System.getProperty("user.home") + "/Desktop" + "/NewDog.jpg";
		try {
			ByteArrayInputStream bis = new ByteArrayInputStream(dataReceived);
		    BufferedImage bImage2 = ImageIO.read(bis);
		    ImageIO.write(bImage2, "jpg", new File(filePath));
		    }
		catch (IOException e) {
			e.printStackTrace();
		}
	}
}