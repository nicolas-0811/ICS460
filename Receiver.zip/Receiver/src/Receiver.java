import java.awt.image.BufferedImage;
import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.ArrayList;
import java.util.Arrays;

import javax.imageio.ImageIO;

public class Receiver {
	private static byte[] dataReceived;
	private static final int RANDOM_PORT = 555;
	private static ArrayList<byte[]> packetsReceived = new ArrayList<byte[]>();
	
	public Receiver() {	
	}
	
	public static void main(String[] args) throws IOException, InterruptedException {
		Receiver receiver = new Receiver();
		receiver.receiveData();
		receiver.assembleFile();
		receiver.writeFile();
		System.out.println("Success! Check your desktop to see the received image");
	}	
	
	public void receiveData() throws IOException {
		DatagramSocket ds = new DatagramSocket(RANDOM_PORT);
		byte[] initialSize = new byte[100000]; //A default array size that will be more than capable of holding each incoming packet, its length gets cut off later on
		boolean keepGoing = true;
		int startOff = 0;
		int endOff = 0;
		
		while(keepGoing) {
			DatagramPacket dp = new DatagramPacket(initialSize, initialSize.length);
			ds.receive(dp);	
			byte[] buffer = dp.getData();
			if (dp.getLength() == 0) {
				keepGoing = false;
				break;
			}		
			else {
				buffer = Arrays.copyOf(buffer, dp.getLength());	
				packetsReceived.add(buffer);
				endOff = endOff + buffer.length;
				System.out.printf("[Packet#%d]-[Start byte offset: %d]-[End byte offset: %d]\n", packetsReceived.size(), startOff, endOff - 1);
				startOff = startOff + buffer.length;
			}					
		}
			ds.close();	
		}       
	
	public void assembleFile() {
		dataReceived = new byte[0];
		int newLength = 0;
		int index = 0;
		for (int i = 0; i < packetsReceived.size(); i++) {
			newLength = newLength + packetsReceived.get(i).length;
			dataReceived = Arrays.copyOf(dataReceived, newLength);
			for (int j = 0; j < packetsReceived.get(i).length; j++) {
				dataReceived[index] = packetsReceived.get(i)[j];
				index++;
			}		
		}
	}
		
	public void writeFile() throws IOException {
		ByteArrayInputStream bis = new ByteArrayInputStream(dataReceived);
	    BufferedImage bImage2 = ImageIO.read(bis);
	    String outputPath = System.getProperty("user.home") + "/Desktop" + "/newDog.jpg";
	    ImageIO.write(bImage2, "jpg", new File(outputPath));
	}
}