import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.ArrayList;

public class Receiver {
	private byte[] dataReceived;
	private ArrayList<DatagramPacket> packetsReceived = new ArrayList<DatagramPacket>();
	
	public Receiver() {	
	}
	
	public void receiveData() throws IOException{
		DatagramSocket ds = new DatagramSocket(1234);
        Sender sender = new Sender();
        dataReceived = new byte[(int) sender.getDataLength()];
        DatagramPacket dpReceive = null;
        
        for (int i = 0; i < sender.getNumPackets(); i++) {
        	//Create the required number of packets that the sender class will send
        }       
        ds.close();
	}	
}