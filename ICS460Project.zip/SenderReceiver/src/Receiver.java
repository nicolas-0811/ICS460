import java.io.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

public class Receiver {
	
	public static void main(String args []) throws IOException {
		
	}

}
