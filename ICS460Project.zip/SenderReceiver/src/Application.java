import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class Application {

	public static void main(String[] args) throws IOException{
		Sender sender = new Sender();
		sender.readImage();
		sender.imageToBytes();
		sender.sendImagePrint();
		sender.sendImage();
	}
}