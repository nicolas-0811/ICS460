import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

public class Sender {
	
	private byte[] data;
	private byte[][] parts;
	private static BufferedImage image = null;
	
	public Sender() {
		//For some reason I wasn't able to use the readImage() method without instantiating first
	}
	
	public static void main(String args []) throws IOException {
		Sender sender = new Sender();
		sender.readImage();
		sender.imageToBytes();
	}
	
	public void readImage() throws IOException {
		try {
			String fileName = "res/Dog.jpg";
			ClassLoader classLoader = getClass().getClassLoader();
			File input = new File(classLoader.getResource(fileName).getFile());
			//System.out.println("File found: " + input.exists());
			image = ImageIO.read(input);
			
			FileInputStream fis = null;
			data = new byte[(int) input.length()];
			fis = new FileInputStream(input);
			fis.read(data);
			fis.close();
		}
		catch (Exception e) {
			System.out.println("Error: " + e);
		}		
	}
	
	public void imageToBytes() throws IOException {
		//Divinding the file size in 17 equal parts
		int blockSize = data.length / 16;
		int blockCount = (data.length + blockSize - 1) / blockSize;
		//Creating 17 arrays that will represent the 17 parts of the file
		parts = new byte[blockCount][];
		int index = 0;
		for (int i = 0; i < blockCount; i++) {
			parts[i] =  new byte[blockSize];
			index++;
		}

		for (int i = 1; i < blockCount; i++) {
			int idx = (i - 1) * blockSize;
			parts[i] = Arrays.copyOfRange(data, idx, idx + blockSize);
			System.out.println("Chunk " + i + ": " + Arrays.toString(parts));		
		}
		
		// Last chunk
		int end = -1;
		if (data.length % blockSize == 0) {
				end = data.length;
		} else {
				end = data.length % blockSize + blockSize * (blockCount - 1);
		}
						
		parts[index - 1] = Arrays.copyOfRange(data, (blockCount - 1) * blockSize, end);

		System.out.println("Chunk " + blockCount + ": " + Arrays.toString(parts));
	}
}