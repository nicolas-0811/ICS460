import java.io.*;
import java.util.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.io.ByteArrayOutputStream;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

public class Sender {
	
	private static byte[] data;
	private static final int RANDOM_PORT = 555;
	private static ArrayList<byte[]> chunks = new ArrayList<byte[]>();
	private int blockSize = 1000; //Making each package 1000 bytes long just for convenience
	private static ArrayList<DatagramPacket> packets = new ArrayList<DatagramPacket>();
	
	public Sender() {
	}	
	
	public static void main (String[] args) throws IOException, InterruptedException {
		Sender sender = new Sender();
		sender.readImage2();
		sender.imageToBytes();
		sender.sendImage();	
	}
	
	public void readImage2() throws IOException {
		try {
			String fileName = "res/Dog.jpg";
			ClassLoader classLoader = getClass().getClassLoader();
			File input = new File(classLoader.getResource(fileName).getFile());
			BufferedImage bImage = ImageIO.read(input);
		    ByteArrayOutputStream bos = new ByteArrayOutputStream();
		    ImageIO.write(bImage, "jpg", bos);
		    data = bos.toByteArray();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void readImage() throws IOException {
		try {
			String fileName = "res/Dog.jpg";
			ClassLoader classLoader = getClass().getClassLoader();
			File input = new File(classLoader.getResource(fileName).getFile());

			data = new byte[(int) input.length()];
			FileInputStream fis = new FileInputStream(input);
			fis.read(data);
			fis.close();
		}
		catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	public void imageToBytes() throws IOException {
	
		int blockCount = (data.length + blockSize - 1) / blockSize;

		for (int i = 1; i < blockCount; i++) {
			byte[] temp = new byte[blockSize];
			int idx = (i - 1) * blockSize;
			temp = Arrays.copyOfRange(data, idx, idx + blockSize);
			chunks.add(temp);		
		}
		
		//Last chunk
		int end = -1;
		if (data.length % blockSize == 0) {
				end = data.length;
		} else {
				end = data.length % blockSize + blockSize * (blockCount - 1);
		}
		
		byte[] temp = new byte[blockSize];
		temp = Arrays.copyOfRange(data, (blockCount - 1) * blockSize, end);
		chunks.add(temp);
	}
	
	public void sendImage() throws IOException {
		
		DatagramSocket ds = new DatagramSocket();
		InetAddress ip = InetAddress.getLocalHost();
		for (int i = 0; i < chunks.size(); i++) { //Populating the arraylist that will hold the DatagramPacket objects
			DatagramPacket newPacket = new DatagramPacket(chunks.get(i), chunks.get(i).length, ip, RANDOM_PORT);
			packets.add(newPacket);		
		}
		int startOff = 0;
		int endOff = 0;
		for (int i = 0; i < packets.size(); i++) { //Sending each packet individually
			try {
				ds.send(packets.get(i));
				if (i == (chunks.size() - 1)) {
					System.out.printf("[Packet#%d]-[Start byte offset: %d]-[End byte offset: %d]\n", i + 1, endOff + 1, data.length);
				}
				else {
					startOff = blockSize * i;
					endOff = startOff + (blockSize - 1);
					System.out.printf("[Packet#%d]-[Start byte offset: %d]-[End byte offset: %d]\n", i + 1, startOff, endOff);
				}	
				
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		byte [] last = new byte[0];
		DatagramPacket tail = new DatagramPacket(last, last.length, ip, RANDOM_PORT);
		ds.send(tail);
		ds.close();
	}
	
	public void createPackets() throws IOException{
		InetAddress ip = InetAddress.getLocalHost();
		for (int i = 0; i < chunks.size(); i++) { //Populating the arraylist that will hold the DatagramPacket objects
			packets.add(new DatagramPacket(chunks.get(i), chunks.get(i).length, ip, RANDOM_PORT));		
		}
	}
	
	public byte[] getData() {
		return data;
	}
	
	public int getDataLength() {
		return data.length;
	}
	
	public int getNumPackets() {
		return chunks.size();
	}
	
	public byte[] getSpecificPacket(int index) {
		return chunks.get(index);
	}
	
	public int getPacketLength(int index) {
		return chunks.get(index).length;
	}
}